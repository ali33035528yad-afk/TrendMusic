# TrendMusic 🎵

نسخه اولیه رابط کاربری اپلیکیشن موسیقی TrendMusic با Kotlin و Jetpack Compose.

## وضعیت
- رابط کاربری فارسی و راست‌به‌چپ
- صفحه خانه، جستجو، علاقه‌مندی‌ها و پروفایل
- مینی‌پلیر نمایشی
- این نسخه هنوز پخش واقعی موسیقی یا API آنلاین ندارد.

## ساخت APK
این پروژه یک پروژه استاندارد Android/Gradle است. برای ساخت نسخه آزمایشی، از Gradle با تسک زیر استفاده کنید:

```bash
gradle assembleDebug
```

خروجی APK در مسیر زیر قرار می‌گیرد:

`app/build/outputs/apk/debug/app-debug.apk`
