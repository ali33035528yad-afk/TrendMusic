package com.trendmusic.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF070B16)
private val Card = Color(0xFF10182A)
private val Pink = Color(0xFFFF20B8)
private val Purple = Color(0xFF7A4DFF)
private val Text = Color(0xFFF5F7FF)
private val Muted = Color(0xFF98A1B7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TrendMusicApp() }
    }
}

@Composable
fun TrendMusicApp() {
    var selected by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Card,
            primary = Pink,
            onBackground = Text,
            onSurface = Text
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Scaffold(
                containerColor = Bg,
                bottomBar = {
                    Column {
                        if (playing) MiniPlayer()
                        NavigationBar(containerColor = Color(0xFF0A1020)) {
                            NavItem(Icons.Default.Home, "خانه", selected == 0) { selected = 0 }
                            NavItem(Icons.Default.Search, "جستجو", selected == 1) { selected = 1 }
                            NavItem(Icons.Default.FavoriteBorder, "علاقه‌مندی", selected == 2) { selected = 2 }
                            NavItem(Icons.Default.Person, "پروفایل", selected == 3) { selected = 3 }
                        }
                    }
                }
            ) { padding ->
                when (selected) {
                    0 -> HomeScreen(padding) { playing = true }
                    1 -> SearchScreen(padding)
                    2 -> FavoritesScreen(padding)
                    else -> ProfileScreen(padding)
                }
            }
        }
    }
}

@Composable
fun NavItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    NavigationBarItem(
        selected = active,
        onClick = onClick,
        icon = { Icon(icon, null) },
        label = { Text(label, fontSize = 11.sp) },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = Pink,
            selectedTextColor = Pink,
            unselectedIconColor = Muted,
            unselectedTextColor = Muted,
            indicatorColor = Color.Transparent
        )
    )
}

@Composable
fun HomeScreen(padding: PaddingValues, onPlay: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp).verticalScroll(rememberScrollState())
    ) {
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("TrendMusic", fontSize = 25.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f))
            IconButton(onClick = {}) { Icon(Icons.Default.Search, "جستجو") }
            IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, "اعلان‌ها") }
        }

        Spacer(Modifier.height(12.dp))
        HeroCard()

        SectionTitle("آهنگ‌های ترند امروز", "مشاهده همه")
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            SongCard("Espresso", "Sabrina Carpenter", "01", onPlay)
            SongCard("Beautiful Things", "Benson Boone", "02", onPlay)
            SongCard("Lose Control", "Teddy Swims", "03", onPlay)
        }

        SectionTitle("ترند اینستاگرام", "همه")
        TrendRow("Espresso", "Sabrina Carpenter", Icons.Default.CameraAlt, onPlay)
        TrendRow("Beautiful Things", "Benson Boone", Icons.Default.CameraAlt, onPlay)
        TrendRow("A Bar Song", "Shaboozey", Icons.Default.CameraAlt, onPlay)

        SectionTitle("ترند TikTok", "همه")
        TrendRow("Dreams", "Fleetwood Mac", Icons.Default.MusicNote, onPlay)
        TrendRow("Apple", "Charli XCX", Icons.Default.MusicNote, onPlay)
        TrendRow("Million Dollar Baby", "Tommy Richman", Icons.Default.MusicNote, onPlay)
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
fun HeroCard() {
    Box(
        Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(Purple, Pink, Color(0xFF16204B))))
            .padding(22.dp)
    ) {
        Column(Modifier.align(Alignment.CenterEnd), horizontalAlignment = Alignment.End) {
            Text("آهنگ‌های ترند\nخوش آمدید 🎧", fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(14.dp))
            Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) {
                Text("مشاهده ترندها")
            }
        }
    }
}

@Composable
fun SectionTitle(title: String, action: String) {
    Row(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Text(action, color = Pink, fontSize = 13.sp)
    }
}

@Composable
fun SongCard(title: String, artist: String, seed: String, onPlay: () -> Unit) {
    Column(Modifier.width(145.dp).padding(end = 10.dp).clickable { onPlay() }) {
        Box(
            Modifier.fillMaxWidth().height(145.dp).clip(RoundedCornerShape(18.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF273A6D), Color(0xFF151B30))))
        ) {
            Text(seed, fontSize = 44.sp, color = Color.White.copy(alpha = .18f),
                modifier = Modifier.align(Alignment.Center))
            Box(Modifier.align(Alignment.BottomEnd).padding(8.dp).size(38.dp).clip(CircleShape)
                .background(Pink), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.PlayArrow, null, tint = Color.White)
            }
        }
        Text(title, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 7.dp))
        Text(artist, color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun TrendRow(title: String, artist: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onPlay: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).clickable { onPlay() }
            .padding(10.dp), verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF202B49)),
            contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = Pink) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(artist, color = Muted, fontSize = 12.sp)
        }
        Icon(icon, null, tint = Muted)
        IconButton(onClick = onPlay) { Icon(Icons.Default.PlayCircle, null, tint = Pink) }
    }
    Spacer(Modifier.height(8.dp))
}

@Composable
fun SearchScreen(padding: PaddingValues) {
    Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
        Text("جستجو", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(value = "", onValueChange = {}, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("نام آهنگ، خواننده یا هشتگ...") },
            leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Text("جستجوهای اخیر", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 28.dp, bottom = 12.dp))
        listOf("shakira", "tiktok viral", "sabrina carpenter", "teddy swims").forEach {
            AssistChip(onClick = {}, label = { Text(it) }, modifier = Modifier.padding(end = 6.dp, bottom = 8.dp))
        }
    }
}

@Composable
fun FavoritesScreen(padding: PaddingValues) {
    Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
        Text("علاقه‌مندی‌ها ❤️", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        listOf("Espresso", "Beautiful Things", "Flowers", "Calm Down").forEach {
            TrendRow(it, "هنرمند مورد علاقه", Icons.Default.Favorite, {})
            Spacer(Modifier.height(2.dp))
        }
    }
}

@Composable
fun ProfileScreen(padding: PaddingValues) {
    Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(20.dp))
        Box(Modifier.size(90.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Pink, Purple))),
            contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Person, null, modifier = Modifier.size(48.dp))
        }
        Text("MusicLover ✎", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
        Text("عاشق موسیقی ❤️", color = Muted)
        Spacer(Modifier.height(24.dp))
        Button(onClick = {}, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Pink)) { Text("ویرایش پروفایل") }
        Spacer(Modifier.height(10.dp))
        listOf("لیست‌های من", "دانلودها", "تنظیمات", "پشتیبانی", "درباره ما").forEach {
            ListItem(headlineContent = { Text(it) }, trailingContent = { Icon(Icons.Default.ChevronLeft, null) })
        }
    }
}

@Composable
fun MiniPlayer() {
    Row(Modifier.fillMaxWidth().background(Color(0xFF121A2C)).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)).background(Purple), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.MusicNote, null)
        }
        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
            Text("Espresso", fontWeight = FontWeight.SemiBold)
            Text("Sabrina Carpenter", color = Muted, fontSize = 11.sp)
        }
        IconButton(onClick = {}) { Icon(Icons.Default.SkipPrevious, null) }
        IconButton(onClick = {}) { Icon(Icons.Default.PauseCircle, null, tint = Pink) }
        IconButton(onClick = {}) { Icon(Icons.Default.SkipNext, null) }
    }
}
